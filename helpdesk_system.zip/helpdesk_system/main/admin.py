from django.contrib import admin
from main.models import *

# Register your models here.
admin.site.register(Ticket)
admin.site.register(Faq)
admin.site.register(Community)
admin.site.register(Post)
admin.site.register(Chat)
admin.site.register(Category)
admin.site.register(Agent)
