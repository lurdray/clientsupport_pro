from django.db import models

from django.utils import timezone
import uuid


# models.py
from django.db import models

class Agent(models.Model):
    ROLE_CHOICES = [
        ("support", "Support Agent"),
        ("manager", "Manager"),
        ("admin", "Admin"),
    ]

    name = models.CharField(max_length=150)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=20, blank=True, null=True)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default="support")
    created_at = models.DateTimeField(auto_now_add=True)
    
    status = models.BooleanField(default=False, null=True, blank=True)  # False = unresolved, True = resolved

    def __str__(self):
        return self.name






        

class Category(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    title = models.CharField(max_length=150)
    
    assigned_agent = models.ForeignKey(
        "Agent", on_delete=models.SET_NULL, null=True, blank=True, related_name="categories"
    )
    
    description = models.TextField()

    pub_date = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.title



class Faq(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    question = models.TextField()
    answer = models.TextField()

    pub_date = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.question


class Chat(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    message = models.TextField()
    reply = models.TextField()

    pub_date = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.message


class Post(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    sender = models.CharField(max_length=200)
    message = models.TextField()

    pub_date = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.sender

class Ticket(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=200)
    email = models.CharField(max_length=200)
    otp = models.CharField(max_length=200)
    
    subject = models.CharField(max_length=200, null=True, blank=True)
    priority = models.CharField(max_length=200, null=True, blank=True)
    progress = models.CharField(max_length=200, null=True, blank=True)

    chats = models.ManyToManyField(Chat, through="TicketChatConnector")

    assigned_to = models.CharField(max_length=200, null=True, blank=True)
    assigned_to_id = models.CharField(max_length=200, null=True, blank=True)

    # --- Analytics fields ---
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)  # when ticket was created
    first_response_at = models.DateTimeField(null=True, blank=True)  # when first response happened
    resolved_at = models.DateTimeField(null=True, blank=True)  # when marked as resolved

    # optional: store durations directly (or compute them dynamically)
    time_to_first_response = models.DurationField(null=True, blank=True)
    resolution_time = models.DurationField(null=True, blank=True)

    status = models.BooleanField(default=False, null=True, blank=True)  # False = unresolved, True = resolved
    pub_date = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.subject if self.subject else f"Ticket {self.id}"




class Community(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    
    title = models.CharField(max_length=150)
    description = models.TextField()

    posts = models.ManyToManyField(Post, through="CommunityPostConnector")

    assigned_to = models.CharField(max_length=200, null=True, blank=True)
    assigned_to_id = models.CharField(max_length=200, null=True, blank=True)

    status = models.BooleanField(default=False, null=True, blank=True)
    pub_date = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.title
        

class TicketChatConnector(models.Model):
	ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE)
	chat = models.ForeignKey(Chat, on_delete=models.CASCADE)
	pub_date = models.DateTimeField(default=timezone.now)
	
	
class CommunityPostConnector(models.Model):
	community = models.ForeignKey(Community, on_delete=models.CASCADE)
	post = models.ForeignKey(Post, on_delete=models.CASCADE)
	pub_date = models.DateTimeField(default=timezone.now)
