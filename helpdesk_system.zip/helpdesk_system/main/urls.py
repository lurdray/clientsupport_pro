from django.urls import path
from . import views

app_name = "main"

urlpatterns = [
    
    path("landing/", views.index, name="index"),
    path("", views.sign_in, name="sign_in"),
    path("sign-up/", views.sign_up, name="sign_up"),
    path("sign-out/", views.sign_out, name="sign_out"),

    path("profile/", views.profile, name="profile"),
    
    path("all-category/", views.all_category, name="all_category"),
    path("add-category/", views.add_category, name="add_category"),
    
    path("analytics/", views.analytics, name="analytics"),
    
    
    path("agent/", views.agent, name="agent"),
    path("agent-verify/", views.agent_verify, name="agent_verify"),
    path("agent-dashboard/<str:ticket_id>/", views.agent_dashboard, name="agent_dashboard"),
    path("agent-dashboard/<str:ticket_id>/resolve/", views.agent_resolve, name="agent_resolve"),
    path("agent-status/<str:ticket_id>/", views.agent_status, name="agent_status"),
    path("agent-logout/", views.agent_logout, name="agent_logout"),
    
    path("community/", views.community, name="community"),
    path("community-detail/<str:id>/", views.community_detail, name="community_detail"),
    path("add-community/", views.add_community, name="add_community"),
    path("all-community/", views.all_community, name="all_community"),
    path("add-agent-to-community/", views.add_agent_to_community, name="add_agent_to_community"),

    path("ticket/", views.ticket, name="ticket"),
    path("ticket-detail/<str:id>/", views.ticket_detail, name="ticket_detail"),
    path("chat/", views.chat, name="chat"),

    path("faqs/", views.faqs, name="faqs"),
    path("add-faqs/", views.add_faqs, name="add_faqs"),
    path("edit-faqs/<int:id>/", views.edit_faqs, name="edit_faqs"),
    path("deletes-faqs/<int:id>/", views.delete_faqs, name="delete_faqs"),

    path("add-agent/", views.add_agent, name="add_agent"),
    path("all-agents/", views.all_agents, name="all_agents"),
    path("assign-agent/<str:ticket_id>/", views.assign_agent, name="assign_agent"),

    path("help-desk/<str:id>/", views.help_desk1, name="help_desk1"),
    path("help-desk/<str:email>/verify/", views.help_desk2, name="help_desk2"),
    path("help-desk/<str:email>/dashboard/", views.help_desk3, name="help_desk3"),
    path("help-desk/<str:ticket_id>/chat/interface/", views.help_desk4, name="help_desk4"),
    
    path("reset-password/", views.reset_password, name="reset_password"),
    path("verify-account/", views.verify_account, name="verify_account"),
    

]