from django.shortcuts import render
from django.contrib import messages

from django.shortcuts import render
from django.utils import timezone
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse, reverse_lazy
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.models import User

from app_user.models import AppUser
from main.models import *




from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Agent, Ticket   # assuming you have a Ticket model





from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.conf import settings
from django.core.mail import EmailMessage

from django.conf import settings
from django.core.mail import EmailMessage
from django.template.loader import render_to_string


import random
import string




import openai

openai.api_key = "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"


# Function to interact with OpenAI and generate a response based on FAQs and query
def get_faq_response(user_query):
    faqs = Faq.objects.all()
    faq_content = "\n".join([f"Q: {faq.question}\nA: {faq.answer}" for faq in faqs])

    prompt = f"""
    You are a helpful customer support agent. Below is the FAQ knowledge base.

    {faq_content}

    User Query:
    {user_query}

    Provide a helpful, precise answer (not more than 25 words). 
    If the FAQ doesn't contain relevant information, politely say the information is not available. 
    Nudge the user to contact the support for further questions. 
    Answer naturally as a support staff (don’t say 'according to the FAQ' or similar or make reference to the faqs.).
    Respond in the same language the query was asked. If the user asks in question yoruba, process it and respond in the same yoruba language.
    """

    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a knowledgeable support staff."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=500,
    )

    return response['choices'][0]['message']['content']




def send_otp_code(subject, recipient_list, context):
    # Render the HTML content with the context data
    html_message = render_to_string('main/otp_code.html', context)

    # Create the email message with a custom sender name
    from_email = f"Ticket <{settings.EMAIL_HOST_USER}>"

    email = EmailMessage(
        subject=subject,
        body=html_message,
        from_email=from_email,
        to=recipient_list,
    )

    # Set the email content type to HTML
    email.content_subtype = 'html'

    # Send the email
    email.send()






def send_assign_msg(subject, recipient_list, context):
    # Render the HTML content with the context data
    html_message = render_to_string('main/assign_message.html', context)

    # Create the email message with a custom sender name
    from_email = f"Ticket <{settings.EMAIL_HOST_USER}>"

    email = EmailMessage(
        subject=subject,
        body=html_message,
        from_email=from_email,
        to=recipient_list,
    )

    # Set the email content type to HTML
    email.content_subtype = 'html'

    # Send the email
    email.send()



def send_new_msg(subject, recipient_list, context):
    # Render the HTML content with the context data
    html_message = render_to_string('main/new_message.html', context)

    # Create the email message with a custom sender name
    from_email = f"Ticket <{settings.EMAIL_HOST_USER}>"

    email = EmailMessage(
        subject=subject,
        body=html_message,
        from_email=from_email,
        to=recipient_list,
    )

    # Set the email content type to HTML
    email.content_subtype = 'html'

    # Send the email
    email.send()


def send_new_msg_agent(subject, recipient_list, context):
    # Render the HTML content with the context data
    html_message = render_to_string('main/new_message_agent.html', context)

    # Create the email message with a custom sender name
    from_email = f"Ticket <{settings.EMAIL_HOST_USER}>"

    email = EmailMessage(
        subject=subject,
        body=html_message,
        from_email=from_email,
        to=recipient_list,
    )

    # Set the email content type to HTML
    email.content_subtype = 'html'

    # Send the email
    email.send()

def agent(request):
    #app_user = AppUser.objects.get(user__id=request.user.id)
    #tickets = Ticket.objects.all().order_by('-pub_date')

    if request.method == "POST":
        email = request.POST.get("email")
        
        
        agent = Agent.objects.filter(email=email).last()
        
        if not agent:
            messages.warning(request, "Invallid Agent Account!")
            return HttpResponseRedirect(reverse("main:agent"))

            
            
            
        recipient_list = [email]
        
        request.session["email"] = str(email)
        request.session.modified = True  # Ensure session is marked as updated
        
        otp_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

        # Save to session
        request.session["session_otp"] = otp_code
        request.session.modified = True  # Ensure session is marked as updated

        
        context = {"otp_code": otp_code}
        send_otp_code("Your OTP Code is here.", recipient_list, context)
        
        
        messages.warning(request, "Confirm your email address")
        return HttpResponseRedirect(reverse("main:agent_verify"))




    else:
        context = {
        #    "app_user": app_user,
        #    "tickets": tickets
        }
        return render(request, "main/agent.html", context )



def agent_verify(request):
    #app_user = AppUser.objects.get(user__id=request.user.id)
    #tickets = Ticket.objects.all().order_by('-pub_date')

    if request.method == "POST":
        otp = request.POST.get("otp_code")

        #verify otp here
        session_otp = request.session.get("session_otp")
        email = request.session.get("email")
        
        
        agent = Agent.objects.filter(email=email).last()
        
        if agent:
    
            tickets = Ticket.objects.filter(assigned_to_id=agent.id)
            ticket = tickets.last()
            if ticket:
                ticket_id = ticket.id
            else:
                ticket_id = None
                
            
        else:
            ticket_id = None
            
        
        
        if otp == session_otp:
            messages.warning(request, "You otp was verified successfully.")
            return HttpResponseRedirect(reverse("main:agent_dashboard", args=[ticket_id]))
            
        else:
            messages.warning(request, "Failed to verify OTP code.")
            return HttpResponseRedirect(reverse("main:agent_verify"))





    else:
        context = {
        #    "app_user": app_user,
        #    "tickets": tickets
        }
        return render(request, "main/agent_verify.html", context )


    


def agent_dashboard(request, ticket_id):
    email = request.session.get("email")
    
    agent = Agent.objects.filter(email=email).last()
    
    if agent:
        tickets = Ticket.objects.filter(assigned_to_id=agent.id)
        if ticket_id != "None":
            ticket = Ticket.objects.get(id=ticket_id)
        else:
            ticket = None

    
    else:
        tickets = []
        ticket = None

    
        
    if request.method == "POST":
        message = request.POST.get("message")

        ####
        #response = get_faq_response(message)
        
        from django.utils.timezone import now

        if not ticket.first_response_at:  # only set it the first time
            ticket.first_response_at = now()
            ticket.save()
            
        
        chat = Chat.objects.create(message=message, reply=message)
        chat.save()
        
        tc = TicketChatConnector(ticket=ticket, chat=chat)
        tc.save()
        
        agent_id = ticket.assigned_to_id
        agent = Agent.objects.get(id=agent_id)
        
        ticket_link = "https://ticket.stalwartng.com/help-desk/%s/chat/interface/" % ticket_id
        context = {"ticket_link": ticket_link}
        
        send_new_msg_agent("You have a new Message from %s" % agent.email, [ticket.email,], context)
        
        #messages.warning(request, "You otp was verified successfully.")
        return HttpResponseRedirect(reverse("main:agent_dashboard", args=[ticket.id]))



    else:
        if ticket:
            chats = ticket.chats.all().order_by('pub_date')
        else:
            chats = None
        context = {
            "agent": agent,
            "tickets": tickets,
            "ticket": ticket,
            "chats": chats,
        }
        return render(request, "main/agent_dashboard.html", context )





def agent_resolve(request, ticket_id):
    email = request.session.get("email")
    
    agent = Agent.objects.filter(email=email).last()
    
    if agent:
        tickets = Ticket.objects.filter(assigned_to_id=agent.id)
        if ticket_id != "None":
            ticket = Ticket.objects.get(id=ticket_id)
        else:
            ticket = None

    
    else:
        tickets = []
        ticket = None
        
        
    from django.utils.timezone import now

    if not ticket.resolved_at:  # only set it the first time
        ticket.resolved_at = now()
        ticket.status = True
        ticket.save()
        
    messages.warning(request, "Ticket status updated successfully.")
    return HttpResponseRedirect(reverse("main:agent_dashboard", args=[ticket.id]))

     
     
 
def agent_status(request, ticket_id):
    email = request.session.get("email")
    
    agent = Agent.objects.filter(email=email).last()
    
    if agent:
        tickets = Ticket.objects.filter(assigned_to_id=agent.id)
        if ticket_id != "None":
            ticket = Ticket.objects.get(id=ticket_id)
        else:
            ticket = None

    
    else:
        tickets = []
        ticket = None
        
        
    if agent.status == True:
        agent.status = False
    else:
        agent.status = True
    agent.save()
    
    messages.warning(request, "Agent status updated successfully.")
    return HttpResponseRedirect(reverse("main:agent_dashboard", args=[ticket.id]))





def agent_logout(request):
    email = request.session.get("email")
    
    agent = Agent.objects.filter(email=email).last()
    agent.status = False
    agent.save()
    
    messages.warning(request, "Agent loggout successfully.")
    return HttpResponseRedirect(reverse("main:agent"))



def all_category(request):
    categories = Category.objects.all().order_by('-pub_date')
    
    context = {"categories":categories}
    return render(request, "main/all_category.html", context)



def add_category(request):
    agents = Agent.objects.all()  # fetch agents for the dropdownd

    if request.method == "POST":
        title = request.POST.get("title")
        description = request.POST.get("description")
        agent_id = request.POST.get("assigned_agent")

        # Get agent if selected
        assigned_agent = None
        if agent_id:
            assigned_agent = get_object_or_404(Agent, id=agent_id)

        # Create category with assigned agent
        category = Category.objects.create(
            title=title,
            description=description,
            assigned_agent=assigned_agent
        )
        category.save()

        messages.success(request, "Category added successfully.")
        return redirect("main:all_category")

    return render(request, "main/add_category.html", {"agents": agents})

def all_agents(request):
    search_query = request.GET.get("search", "")
    agents = Agent.objects.all()

    if search_query:
        agents = agents.filter(name__icontains=search_query) | agents.filter(email__icontains=search_query)

    return render(request, "main/all_agents.html", {"agents": agents})



def add_agent(request):
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        phone = request.POST.get("phone")
        role = request.POST.get("role")

        if not name or not email or not role:
            messages.error(request, "Please fill in all required fields.")
        else:
            Agent.objects.create(
                name=name,
                email=email,
                phone=phone,
                role=role
            )
            messages.success(request, "Agent added successfully.")
            return redirect("main:all_agents")

    return render(request, "main/add_agent.html")



def assign_agent(request, ticket_id):
    ticket = get_object_or_404(Ticket, id=ticket_id)
    agents = Agent.objects.all()

    if request.method == "POST":
        agent_id = request.POST.get("agent")
        if agent_id:
            agent = get_object_or_404(Agent, id=agent_id)
            ticket.assigned_to = str(agent.name)
            ticket.save()
            
            recipient_list = [agent.email]
            ticket_link = "https://ticket.stalwartng.com/help-desk/%s/chat/interface/" % ticket_id
            
            context = {"agent_name": agent.name, "ticket_link": ticket_link}
            send_assign_msg("You've been assigned to a new ticket", recipient_list, context)
        
        
            messages.success(request, f"Ticket assigned to {agent.name}.")
            return redirect("main:ticket")

    return render(request, "main/assign_agent.html", {"ticket": ticket, "agents": agents})



from django.utils.timezone import now
from django.db.models import Count
from django.shortcuts import render

def analytics(request):
    app_user = AppUser.objects.get(user__id=request.user.id)
    tickets = Ticket.objects.all().order_by("-pub_date")
    
    total_tickets = tickets.count()
    resolved_tickets = tickets.filter(resolved_at__isnull=False).count()
    unresolved_tickets = total_tickets - resolved_tickets

    # Add time metrics to each ticket (calculate if missing)
    for t in tickets:
        # Time to first response
        if t.first_response_at:
            t.time_to_first_response = t.first_response_at - t.created_at
        else:
            t.time_to_first_response = None

        # Resolution time
        if t.resolved_at:
            t.resolution_time = t.resolved_at - t.created_at
        else:
            t.resolution_time = None

    context = {
        "app_user": app_user,
        "tickets": tickets,
        "total_tickets": total_tickets,
        "resolved_tickets": resolved_tickets,
        "unresolved_tickets": unresolved_tickets,
    }
    return render(request, "main/analytics.html", context)



def index(request):
    app_user = AppUser.objects.get(user__id=request.user.id)

    if request.method == "POST":
        pass



    else:
        context = {
            "app_user": app_user,
        }
        return render(request, "main/index.html", context )



def ticket(request):
    app_user = AppUser.objects.get(user__id=request.user.id)
    tickets = Ticket.objects.all().order_by('-pub_date')

    if request.method == "POST":
        pass



    else:
        context = {
            "app_user": app_user,
            "tickets": tickets
        }
        return render(request, "main/ticket.html", context )




def ticket_detail(request, id):
    app_user = AppUser.objects.get(user__id=request.user.id)
    #ticket = Ticket.objects.get(id=id)

    if request.method == "POST":
        pass



    else:
        context = {
            #"ticket": ticket,
            "app_user": app_user,
        }
        return render(request, "main/ticket_detail.html", context )



def community(request):
    app_user = AppUser.objects.get(user__id=request.user.id)
    communities = Community.objects.all().order_by('-pub_date')

    if request.method == "POST":
        pass



    else:
        context = {
            "app_user": app_user,
            "communities": communities
        }
        return render(request, "main/community.html", context )




def community_detail(request, id):
    app_user = AppUser.objects.get(user__id=request.user.id)
    community = Community.objects.get(id=id)

    if request.method == "POST":
        message = request.POST.get("message")
        
        post = Post.objects.create(sender=app_user.name, message=message)
        post.save()
        
        cp = CommunityPostConnector(community=community, post=post)
        cp.save()
        
        messages.success(request, "Message sent!")
        return HttpResponseRedirect(reverse("main:community_detail", args=[id,]))





    else:
        agent = Agent.objects.get(id=community.assigned_to_id)
        
        context = {
            "community": community,
            agent: agent,
            "app_user": app_user,
        }
        return render(request, "main/community_detail.html", context )





def chat(request):
    app_user = AppUser.objects.get(user__id=request.user.id)

    if request.method == "POST":
        pass



    else:
        context = {
            "app_user": app_user,
        }
        return render(request, "main/chat.html", context )



def faqs(request):
    app_user = AppUser.objects.get(user__id=request.user.id)
    faqs = Faq.objects.all().order_by("-pub_date")

    if request.method == "POST":
        pass



    else:
        context = {
            "faqs": faqs,
            "app_user": app_user
        }
        return render(request, "main/faqs.html", context )




def add_faqs(request):
    app_user = AppUser.objects.get(user__id=request.user.id)
    if request.method == "POST":
        question = request.POST.get("question")
        answer = request.POST.get("answer")

        faq = Faq.objects.create(question=question, answer=answer)
        faq.save()

        messages.warning(request, "Welcome onboard")
        return HttpResponseRedirect(reverse("main:faqs"))





    else:
        context = {
            "app_user": app_user
        }
        return render(request, "main/add_faqs.html", context )



def profile(request):
    app_user = AppUser.objects.get(user__id=request.user.id)
    url = "https://ticket.stalwartng.com/help-desk/%s/" % app_user.name


    if request.method == "POST":
        pass



    else:
        context = {
            "app_user": app_user,
            "url": url,
        }
        return render(request, "main/profile.html", context )





def help_desk1(request, id):
    url = "https://ticket.stalwartng.com/help-desk/%s/" % id
    #url = "https://127.0.0.1:8000/help-desk/%s/" % id

    


    if request.method == "POST":
        email = request.POST.get("email")
        recipient_list = [email]
        
        request.session["email"] = str(email)
        request.session.modified = True  # Ensure session is marked as updated
        
        otp_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

        # Save to session
        request.session["session_otp"] = otp_code
        request.session.modified = True  # Ensure session is marked as updated

        
        context = {"otp_code": otp_code}
        send_otp_code("Your OTP Code is here.", recipient_list, context)
        
        
        category_id = request.POST.get("category")

        # Get the selected category (if exists)
        category = None
        if category_id:
            try:
                category = Category.objects.get(id=category_id)
            except Category.DoesNotExist:
                messages.error(request, "Invalid category selected")
                return HttpResponseRedirect(reverse("main:help_desk"))
                
        if category:
        
            # Create the ticket with chosen category
            from django.utils.timezone import now

            ticket = Ticket.objects.create(
                name=category.title,
                email=email,
                subject=category.title,
                progress="Open",
                assigned_to=category.assigned_agent.name,
                assigned_to_id=category.assigned_agent.id,
                created_at=now(),
            )
            ticket.save()

            
            request.session["ticket_id"] = str(ticket.id)
            request.session.modified = True  # Ensure session is marked as updated
            
            recipient_list = [category.assigned_agent.email]
            ticket_link = "https://ticket.stalwartng.com/agent/"
            
            context = {"agent_name": category.assigned_agent.name, "ticket_link": ticket_link}
            send_assign_msg("You've been assigned to a new ticket", recipient_list, context)
            
        
        
        
        
        messages.warning(request, "Confirm your email address")
        return HttpResponseRedirect(reverse("main:help_desk2", args=[email]))



    else:
        categories = Category.objects.all().order_by('-pub_date')
        context = {
            "categories": categories,

        }
        return render(request, "main/help_desk1.html", context )



def help_desk2(request, email):
    ticket_id = request.session.get("ticket_id")

    if request.method == "POST":
        otp = request.POST.get("otp_code")

        #verify otp here
        session_otp = request.session.get("session_otp")
        
        
        
        if otp == session_otp:
            messages.warning(request, "You otp was verified successfully.")
            return HttpResponseRedirect(reverse("main:help_desk4", args=[ticket_id,]))
            
        else:
            messages.warning(request, "Failed to verify OTP code.")
            return HttpResponseRedirect(reverse("main:help_desk2", args=[email]))



    else:
        
        ticket = Ticket.objects.get(id=ticket_id)
        
        context = {
            "ticket": ticket
        }
        return render(request, "main/help_desk2.html", context )




def help_desk3(request, email):
    tickets = Ticket.objects.filter(email=email)
    
    if request.method == "POST":
        category_id = request.POST.get("category")

        # Get the selected category (if exists)
        category = None
        if category_id:
            try:
                category = Category.objects.get(id=category_id)
            except Category.DoesNotExist:
                messages.error(request, "Invalid category selected")
                return HttpResponseRedirect(reverse("main:help_desk"))
        
        # Create the ticket with chosen category
        ticket = Ticket.objects.create(
            email=email,
            subject=category.title,
            progress="Open"
        )
        ticket.save()
        
        messages.success(request, "New Ticket Created")
        return HttpResponseRedirect(reverse("main:help_desk4", args=[ticket.id]))
    



    else:
        categories = Category.objects.all().order_by('-pub_date')
        
        context = {
            "categories": categories,
            "tickets": tickets,
        }
        return render(request, "main/help_desk3.html", context )



def help_desk4(request, ticket_id):
    email = request.session.get("email")
    tickets = Ticket.objects.filter(email=email)
    ticket = Ticket.objects.get(id=ticket_id)
    
    if request.method == "POST":
        message = request.POST.get("message")
        
        agent_id = ticket.assigned_to_id
        agent = Agent.objects.get(id=agent_id)

        ####
        if agent.status == True:
            response = " "
        else:
            response = get_faq_response(message)
            context = {"agent_name": agent.name, "ticket_link": "https://ticket.stalwartng.com/agent/"}
        
            send_new_msg_agent("You have a new Message from %s" % email, [agent.email,], context)
        
        
        chat = Chat.objects.create(message=message, reply=response)
        chat.save()
        
        tc = TicketChatConnector(ticket=ticket, chat=chat)
        tc.save()
        
        
        
        
        
        #messages.warning(request, "You otp was verified successfully.")
        return HttpResponseRedirect(reverse("main:help_desk4", args=[ticket.id]))



    else:
        context = {
            "tickets": tickets,
            "ticket": ticket,
            "chats": ticket.chats.all().order_by('pub_date')
        }
        return render(request, "main/help_desk3.html", context )



def edit_faqs(request, id):
    app_user = AppUser.objects.get(user__id=request.user.id)
    faqs = Faq.objects.get(id=id)

    if request.method == "POST":
        pass



    else:
        context = {
            "app_user": app_user,
            "faqs": faqs,
        }
        return render(request, "main/edit_faqs.html", context )



def delete_faqs(request, id):

    faqs = Faq.objects.get(id=id)
    faqs.delete()

    if request.method == "POST":
        pass



    else:
        context = {

        }
        return render(request, "main/delete_faqs.html", context )





def sign_in(request):

    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")

        user = authenticate(request, username=email, password=password)
        
        if user:
            if user.is_active:
                login(request, user)

                app_user = AppUser.objects.get(user__pk=request.user.id)

                messages.warning(request, "Welcome onboard")
                return HttpResponseRedirect(reverse("main:ticket"))
                
            else:
                messages.warning(request, "Login error")
                return HttpResponseRedirect(reverse("main:sign_in"))


        else:
            messages.warning(request, 'Sorry, invalid logins.')
            return HttpResponseRedirect(reverse("main:sign_in"))

    else:
        context = {}
        return render(request, "main/sign_in.html", context )




def sign_up(request):
    if request.method == "POST":

        name = request.POST.get("name")
        email = request.POST.get("email")
        password = request.POST.get("password")


        try:
            AppUser.objects.get(user__email=request.POST.get("username"))
            messages.warning(request, 'Email Address already taken!')
            return HttpResponseRedirect(reverse("main:sign_up"))


        except:
            user = User(username=email, email=email, password=password)
            user.set_password(password)
            user.save()

            #tracking_id = slugify(name)

            #qr_code_data = "http://localhost:8000/web/%s/" % (name) 
            #qr = qrcode.make(qr_code_data)
            #qr_code_io = BytesIO()
            #qr.save(qr_code_io, format='PNG')
            #qr_code_file = ContentFile(qr_code_io.getvalue(), name=f"{name}_qr.png")

            app_user = AppUser.objects.create(user=user, name=name)
            app_user.save()


            if user:
                if user.is_active:
                    login(request, user)
                    messages.warning(request, 'Check your email for your OTP')
                    return HttpResponseRedirect(reverse("main:ticket"))
                    

    else:
        context = {}
        return render(request, "main/sign_up.html", context )





def sign_out(request):

    logout(request)
    return HttpResponseRedirect(reverse("main:sign_in"))






def reset_password(request):
    #app_user = AppUser.objects.get(user__id=request.user.id)

    if request.method == "POST":
        pass



    else:
        context = {
            #"app_user": app_user,
        }
        return render(request, "main/reset_password.html", context )





def verify_account(request):
    #app_user = AppUser.objects.get(user__id=request.user.id)

    if request.method == "POST":
        pass



    else:
        context = {
            #"app_user": app_user,
        }
        return render(request, "main/verify_account.html", context )




def add_community(request):
    #app_user = AppUser.objects.get(user__id=request.user.id)

    if request.method == "POST":
        title = request.POST.get("title")
        description = request.POST.get("description")
        agent = request.POST.get("agent")
        
        agent = Agent.objects.get(id=agent)
        
        community = Community.objects.create(title=title, description=description, assigned_to=agent.name, assigned_to_id=agent.id)
        community.save()
        
        messages.warning(request, 'Community created successfully')
        return HttpResponseRedirect(reverse("main:all_community"))
                    
        



    else:
        agents = Agent.objects.all().order_by('-created_at')
        context = {
            #"app_user": app_user,
            "agents": agents
        }
        return render(request, "main/add_community.html", context )


def all_community(request):
    #app_user = AppUser.objects.get(user__id=request.user.id)

    if request.method == "POST":
        pass



    else:
        communities = Community.objects.all().order_by('-pub_date')
        context = {
            #"app_user": app_user,
            "communities": communities
        }
        return render(request, "main/all_community.html", context )



def add_agent_to_community(request):
    #app_user = AppUser.objects.get(user__id=request.user.id)

    if request.method == "POST":
        pass



    else:
        context = {
            #"app_user": app_user,
        }
        return render(request, "main/add_agent_to_community.html", context )
