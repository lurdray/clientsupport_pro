from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone


#from project.models import Project

# Create your models here.




class AppUser(models.Model):
	user = models.OneToOneField(User, on_delete=models.CASCADE)
	name = models.CharField(max_length=100, default="null")
	account_type = models.CharField(max_length=100, default="null")
	auth_code = models.CharField(max_length=100, default="null")

	#projects = models.ManyToManyField(Project, through="AppUserProjectConnector")

	pub_date = models.DateTimeField(default=timezone.now)

	def __str__(self):
		return str(self.user.username)







class AppUserProjectConnector(models.Model):
	app_user = models.ForeignKey(AppUser, on_delete=models.CASCADE)
	#project = models.ForeignKey(Project, on_delete=models.CASCADE)
	pub_date = models.DateTimeField(default=timezone.now)



